# cs3219-b2-travis

## Travis CI used for Mocha, Chai & Chai HTTP 